#!/bin/bash

sudo systemctl restart tomcat
